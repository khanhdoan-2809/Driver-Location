import boto3
import json
import uuid
from datetime import date

dynamodb = boto3.client("dynamodb")
def lambda_handler(event, context):
    print(event)
    print(context)

    table_name = "DriverLocation"
    id =  str(uuid.uuid4())
    today = str(date.today())
    item = {
        "ID": {'S': id},
        "UserID": {'S': "user001"},
        "Latitude": {'S': "Latitude001"},
        "Longtitude": {'S': "Longtitude001"},
        "Date": {'S': today},
    }
    
    dynamodb.put_item(
        TableName = table_name,
        Item = item
    )

    message = json.loads(event['Records'][0]['body'])
    body = body['Message']
    print(message)
    print(body)
    print(body.lattitude)
    print(body.longtitude)
    
    return "oke"

lambda_handler("", "")